package com.example.parouimpar

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.example.parouimpar.databinding.ActivityMainBinding
import kotlin.random.Random

class MainActivity : ComponentActivity() {

    private lateinit var binding: ActivityMainBinding
    private var valorPlayer: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.textView1.setOnClickListener {
            setPlayerValue(1)
        }
        binding.textView2.setOnClickListener {
            setPlayerValue(2)
        }
        binding.textView3.setOnClickListener {
            setPlayerValue(3)
        }
        binding.textView4.setOnClickListener {
            setPlayerValue(4)
        }
        binding.textView5.setOnClickListener {
            setPlayerValue(5)
        }

        binding.textViewPar.setOnClickListener {
            if (valorPlayer != null) {
                val resultado = calcularResultado("Par", valorPlayer!!)
                binding.TextViewresultado.text = resultado
                showToast(resultado)
            } else {
                showToast("Escolha o seu numero.")
            }
        }

        binding.textViewImpar.setOnClickListener {
            if (valorPlayer != null) {
                val resultado = calcularResultado("Ímpar", valorPlayer!!)
                binding.TextViewresultado.text = resultado
                showToast(resultado)
            } else {
                showToast("Escolha o seu numero.")
            }
        }
    }

    private fun setPlayerValue(value: Int) {
        valorPlayer = value
        binding.numeroTextView.text = value.toString()
    }

    private fun calcularResultado(escolhaParOuImpar: String, escolhaPlayer: Int): String {
        val escolhaPC: Int = Random.nextInt(6)
        binding.textViewComputer.text = escolhaPC.toString()
        val soma: Int = escolhaPlayer + escolhaPC
        return if ((soma % 2 == 0 && escolhaParOuImpar == "Par") || (soma % 2 != 0 && escolhaParOuImpar == "Ímpar")) {
            "Sua aposta estava correta!"
        } else {
            "Sua aposta estava errada..."
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}